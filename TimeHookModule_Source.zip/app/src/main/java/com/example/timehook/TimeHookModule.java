package com.example.timehook;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.Locale;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class TimeHookModule implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("Hook.JiuWu.Xp")) return;

        XposedBridge.log("TimeHookModule: Hooking into " + lpparam.packageName);

        // Hook System.currentTimeMillis()
        XposedHelpers.findAndHookMethod("java.lang.System", lpparam.classLoader, "currentTimeMillis",
                XC_MethodReplacement.returnConstant(1721347200000L));

        // Hook new Date()
        XposedHelpers.findAndHookConstructor("java.util.Date", XC_MethodReplacement.returnConstant(new Date(1721347200000L)));

        // Hook Calendar.getInstance()
        Calendar fakeCal = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
        fakeCal.setTimeInMillis(1721347200000L);
        XposedHelpers.findAndHookMethod("java.util.Calendar", lpparam.classLoader, "getInstance",
                XC_MethodReplacement.returnConstant(fakeCal));
    }
}
